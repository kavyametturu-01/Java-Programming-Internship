import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 1234);

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter message: ");
            String msg = sc.nextLine();

            output.println(msg);

            socket.close();
            sc.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
