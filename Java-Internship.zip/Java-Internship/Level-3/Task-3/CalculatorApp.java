import javax.swing.*;
import java.awt.event.*;

public class CalculatorApp {
    static String operator = "";
    static int num1 = 0, num2 = 0;

    public static void main(String[] args) {

        JFrame frame = new JFrame("Calculator");
        JTextField tf = new JTextField();

        tf.setBounds(30, 20, 220, 30);

        // Number buttons
        JButton[] buttons = new JButton[10];
        int x = 30, y = 70;

        for (int i = 1; i <= 9; i++) {
            buttons[i] = new JButton(String.valueOf(i));
            buttons[i].setBounds(x, y, 50, 50);
            frame.add(buttons[i]);

            int num = i;
            buttons[i].addActionListener(e -> tf.setText(tf.getText() + num));

            x += 60;
            if (i % 3 == 0) {
                x = 30;
                y += 60;
            }
        }

        // Button 0
        buttons[0] = new JButton("0");
        buttons[0].setBounds(90, y, 50, 50);
        frame.add(buttons[0]);
        buttons[0].addActionListener(e -> tf.setText(tf.getText() + "0"));

        // Operators
        JButton add = new JButton("+");
        JButton sub = new JButton("-");
        JButton mul = new JButton("*");
        JButton div = new JButton("/");
        JButton eq = new JButton("=");
        JButton clr = new JButton("C");

        add.setBounds(210, 70, 50, 50);
        sub.setBounds(210, 130, 50, 50);
        mul.setBounds(210, 190, 50, 50);
        div.setBounds(210, 250, 50, 50);
        eq.setBounds(30, y + 60, 100, 50);
        clr.setBounds(150, y + 60, 100, 50);

        frame.add(add); frame.add(sub); frame.add(mul); frame.add(div);
        frame.add(eq); frame.add(clr);
        frame.add(tf);

        // Operations
        add.addActionListener(e -> {
            num1 = Integer.parseInt(tf.getText());
            operator = "+";
            tf.setText("");
        });

        sub.addActionListener(e -> {
            num1 = Integer.parseInt(tf.getText());
            operator = "-";
            tf.setText("");
        });

        mul.addActionListener(e -> {
            num1 = Integer.parseInt(tf.getText());
            operator = "*";
            tf.setText("");
        });

        div.addActionListener(e -> {
            num1 = Integer.parseInt(tf.getText());
            operator = "/";
            tf.setText("");
        });

        eq.addActionListener(e -> {
            num2 = Integer.parseInt(tf.getText());
            int result = 0;

            switch (operator) {
                case "+": result = num1 + num2; break;
                case "-": result = num1 - num2; break;
                case "*": result = num1 * num2; break;
                case "/": result = num1 / num2; break;
            }

            tf.setText(String.valueOf(result));
        });

        clr.addActionListener(e -> tf.setText(""));

        frame.setSize(320, 450);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}