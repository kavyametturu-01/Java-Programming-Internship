import java.util.Scanner;

public class TicTacToe {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        char[][] board = {
            {' ', ' ', ' '},
            {' ', ' ', ' '},
            {' ', ' ', ' '}
        };

        char player = 'X';
        boolean gameOver = false;

        while (!gameOver) {
            printBoard(board);

            System.out.println("Player " + player + " turn");
            System.out.print("Enter row (0-2): ");
            int row = sc.nextInt();
            System.out.print("Enter column (0-2): ");
            int col = sc.nextInt();

            // Check if cell is empty
            if (board[row][col] == ' ') {
                board[row][col] = player;
            } else {
                System.out.println("Cell already filled! Try again.");
                continue;
            }

            // Check winner
            if (checkWin(board, player)) {
                printBoard(board);
                System.out.println("Player " + player + " wins!");
                gameOver = true;
            } 
            // Check draw
            else if (isDraw(board)) {
                printBoard(board);
                System.out.println("Game is a draw!");
                gameOver = true;
            } 
            // Switch player
            else {
                player = (player == 'X') ? 'O' : 'X';
            }
        }

        sc.close();
    }

    // Print Board
    public static void printBoard(char[][] board) {
        System.out.println("-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }

    // Check Win
    public static boolean checkWin(char[][] b, char p) {
        for (int i = 0; i < 3; i++) {
            if (b[i][0] == p && b[i][1] == p && b[i][2] == p) return true;
            if (b[0][i] == p && b[1][i] == p && b[2][i] == p) return true;
        }
        if (b[0][0] == p && b[1][1] == p && b[2][2] == p) return true;
        if (b[0][2] == p && b[1][1] == p && b[2][0] == p) return true;

        return false;
    }

    // Check Draw
    public static boolean isDraw(char[][] b) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (b[i][j] == ' ') return false;
            }
        }
        return true;
    }
}