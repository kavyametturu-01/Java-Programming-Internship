import java.util.Scanner;

public class PasswordStrengthChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        boolean hasLower = false;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        // Check each character
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isLowerCase(ch)) hasLower = true;
            else if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else hasSpecial = true;
        }

        // Strength checking
        if (password.length() >= 8 && hasLower && hasUpper && hasDigit && hasSpecial) {
            System.out.println("Strong Password ");
        } else if (password.length() >= 6 && (hasLower || hasUpper) && hasDigit) {
            System.out.println("Medium Password ");
        } else {
            System.out.println("Weak Password ");
        }

        sc.close();
    }
}
