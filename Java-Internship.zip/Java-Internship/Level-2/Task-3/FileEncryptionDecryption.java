import java.io.*;
import java.util.Scanner;

public class FileEncryptionDecryption {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter file name: ");
        String fileName = sc.nextLine();

        System.out.print("Choose (1: Encrypt, 2: Decrypt): ");
        int choice = sc.nextInt();

        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);

        String content = "";
        int ch;

        while ((ch = br.read()) != -1) {
            if (choice == 1) {
                content += (char)(ch + 1); // Encryption
            } else if (choice == 2) {
                content += (char)(ch - 1); // Decryption
            }
        }

        br.close();

        String outputFile = (choice == 1) ? "encrypted.txt" : "decrypted.txt";

        FileWriter fw = new FileWriter(outputFile);
        fw.write(content);
        fw.close();

        System.out.println("Process completed. Check file: " + outputFile);

        sc.close();
    }
}