import java.util.Random;
import java.util.Scanner;

public class RandomPasswordGenerator {
    public static void main(String[] args) {
       try( Scanner sc = new Scanner(System.in)){;
        Random rand = new Random();

        System.out.print("Enter password length: ");
        int length = sc.nextInt();

        System.out.print("Include lowercase letters? (true/false): ");
        boolean lower = sc.nextBoolean();

        System.out.print("Include uppercase letters? (true/false): ");
        boolean upper = sc.nextBoolean();

        System.out.print("Include numbers? (true/false): ");
        boolean numbers = sc.nextBoolean();

        System.out.print("Include special characters? (true/false): ");
        boolean special = sc.nextBoolean();

        String chars = "";

        if (lower) chars += "abcdefghijklmnopqrstuvwxyz";
        if (upper) chars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        if (numbers) chars += "0123456789";
        if (special) chars += "!@#$%^&*";

        if (chars.isEmpty()) {
            System.out.println("No character set selected!");
            return;
        }

        String password = "";

        for (int i = 0; i < length; i++) {
            int index = rand.nextInt(chars.length());
            password += chars.charAt(index);
        }

        System.out.println("Generated Password: " + password);
       }
        
    }
}